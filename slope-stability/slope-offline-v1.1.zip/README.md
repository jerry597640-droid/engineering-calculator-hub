# 邊坡穩定分析工作台 1.1.0

線上位置：https://jerry597640-droid.github.io/engineering-calculator-hub/slope-stability/

## 使用

開啟 `index.html`，先載入 10 m 教學範例，再執行三工況分析。左側導覽含詳細操作說明、每個欄位定義、資料來源、可照填範例及驗算結果。支援數字與滑桿、水平分層、剖面座標、靜水壓／ru、均布外載及擬靜態地震。

完整離線 ZIP 解壓縮後開啟 index.html，運算、專案 JSON、詳細 Word、HTML、CSV、SVG、說明與台灣女性旁白操作影片皆可離線使用。單檔 HTML 計算也可離線，影片則使用完整 ZIP。

## 詳細計算書

「匯出詳細 Word 計算書」建立原生 OOXML `.docx`，含三工況判定、地表與土層輸入、剖面、完整公式、代表切片數值代入、Gauss 重量分項、逐片幾何與受力、全部收斂步驟、候選及排除紀錄。完整計算 JSON 另保留所有切片的重量積分分項及未四捨五入數值。附件有可查閱的 10 m 範例計算書。

## 規範版本及範圍

2026-10-11 核對官方原文。

- 水土保持技術規範，114-05-07現行版本，第73條。永久性常時≥1.5、最高水位≥1.2、地震≥1.1；臨時性常時≥1.2、最高水位≥1.1、地震≥1.0。
- 建築物基礎構造設計規範112年版，113-01-01生效。第7.4.4節整體穩定門檻採嚴格大於：長期>1.5、最高水位>1.2、地震>1.1。此選項只套用門檻，地盤模型未含牆體自重、牆體及錨力。完整擋土構造須另行建模分析。
- 第8.4.2節開挖邊坡資料要求列於內嵌說明；沖刷及周圍變形未分析。
- 道路、鐵路、水壩及其他工程可用自訂門檻，須填規範或核定條文。未宣稱通用於所有工程規範。

官方來源：
https://law.moa.gov.tw/LawContent.aspx?id=FL014521
https://www.nlma.gov.tw/ch/legislation/regsearch/962
https://www.nlma.gov.tw/uploads/files/53651dae74223e6599e20838bb8c4f2a.pdf

## 分析模型

Bishop簡化法或Fellenius普通切片法，二維圓弧、水平土層、有效應力、單位剖面寬度1m。內部單位kN、m、kPa，tf=9.80665 kN。三工況各自搜尋，地震再比較±kv。q為垂直外載且不含水平慣性。水位上下分別積分天然／飽和重量；孔隙水壓另扣。

Bishop滿足整體力矩及切片垂直力平衡，未滿足完整水平力平衡；擬靜態地震結果需依案件用完整平衡及適當破壞機制複核。負N′保留並警示，沒有有效結果不視為安全。未實作Spencer、Morgenstern–Price、非圓弧、傾斜弱面、岩塊、地錨／土釘、液化、外部積水、快速洩降或暫態滲流。

## 驗證

`verification.json` 保存 14 項驗證，`tests/verify.py` 為獨立 Python/scipy 核對腳本。所有核對通過：公式求根差最大約3e-9；20萬土柱重量積分相對差最大約5.7e-7；60片/密度14對120片/密度20差小於0.04%。此驗證限已測案例及公式，不是任意工程之安全認證。

Rocscience 官方七片手算：乾坡2.113，程式2.112942660；濕坡最終計算表1.555，程式1.555196431。濕坡原文前段1.553與最終表不一致，依最終表核對。
https://www.rocscience.com/help/slide2/verification-theory/verification-manuals

使用者提供的PDF材料示範為另外建立之水平地層，未宣稱重現原A–A等剖面之FS；原文未提供可直接重建的全部數值幾何。

開發者可於完整原始碼目錄執行 `python tests/verify.py` 重跑驗算；需 Node.js 及 Python numpy、scipy。腳本讀取附帶的 `example-project.json`，產生 `verification.json` 與未四捨五入的 `verification-detail.json`，不依賴本次製作的暫存檔。使用網頁計算及 Word 匯出不需要安裝這些開發套件。

## 建置

`python build.py` 將CSS、求解器、原生Word匯出器及介面JS內嵌成單一index.html。計算不使用CDN、網路API或套件安裝。影片採台灣女性 `zh-TW-HsiaoChenNeural`，有繁體字幕及逐字稿。
