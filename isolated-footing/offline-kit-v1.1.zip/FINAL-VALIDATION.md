# 獨立基礎詳細過程 — 本地驗證

來源：GitHub main `6ac0fd7bd73d59a3a62a0d90e45bbcdbad15f32f`；本組重新讀取 engine、UI、interface、build、tests、README、validation、index、qa-mobile 共9檔。全樹未發現 AGENTS/.agents/skills。本地完成，未提交或推送。

## 修改與發佈檔案

儲存庫：jerry597640-droid/engineering-calculator-hub。

- `isolated-footing/engine.js`：同一次計算留下 Newton/線搜尋、接觸多邊形及積分、傾覆兩側、四柱面與距d剪力、沖切四角及三候選、65次鋼筋二分、應變折減、最小量與短向包絡的實際資料。固定bars表有本次選列。保留原數值公式、floor支數與65次二分。
- `isolated-footing/ui.js`、`interface.html`、`index.html`：繁中動態明細、來源表及逐次二分表、所選組合平面/剖面荷載尺寸圖、真Word匯出；桌機、手機、列印與單檔離線沿用同一trace。
- `isolated-footing/build.py`：保留既有Python builder，明確UTF-8並嵌入共用DOCX runtime與core；離線zip含可重建來源。
- `isolated-footing/offline-kit-v1.1.zip`：本輪全新建置，無沿用舊套件；`build-offline.cjs`可重建。
- 共用 `shared/calculation-docx.js` 與 `vendor/docx/` 使用根代理既有成熟版本，未由本組修改；本工具的index與zip已內嵌當前版本。實際發佈需根代理整合這些既有共用檔。
- 驗證來源：`verify-trace.cjs`、`qa-browser.cjs`、`tests.js`；基準 `qa-baseline-engine.js` 不屬正式網頁依賴。

## 證據

- 原 `node tests.js`：20工程測試群組全部通過。
- `trace-validation.json`：80種厚度、平面、材料、間距、層序、偏心、水位、承載定義與尺寸效應變化，共38,850原有欄位（數值與狀態）比較，全部維持一致；每個柱面AsReq有完整65次實際記錄。另確認null、undefined、null組合安全拒絕。
- `browser-validation.json`：Edge headless file://，1440/768/390/320四寬 × source/safe/ecc/partial四範例 × geometry/loads/soil/steel/report/help六頁；131檢核，0 pageerror、0網路請求、無頁面橫向溢出。
- 桌機/手機 `qa-desktop.docx`、`qa-mobile.docx`：真OOXML ZIP，document.xml包含完整輸入、明細、原生表格及代入；media包含PNG/SVG。`qa-extracted/document.xml`可核對。
- `mode-validation.json`：四個範例全部各自產生Word並檢查原生表、圖與65次記錄，全部單檔HTML還原後輸入及trace相同；負向N/H箭頭另驗方向。
- 原子快照：擷取L=4.5後非同步產生DOCX，期間改L=5，快照仍為4.5；尚未重算、無效尺寸及無壓力接觸解均拒绝匯出。NG數值仍可保留失敗紀錄。
- `qa-offline.html`：下載本次safe輸入，再直接file://開啟，可計算、圖示及Word。
- `offline-validation.json`：本輪ZIP共18項，index與目前本地建置相同；解壓後Python獨立重建也逐字相同。
- `qa-trace-{width}.png`、`qa-diagram-{width}.png`：实际明細與平剖圖區截圖，已目視390及桌機檢查。
- 無Word/LibreOffice排版renderer；已檢查OOXML、表與媒體，未宣稱Word分頁或列印版視覺完美。

## 原引擎限制／疑似問題（未改公式）

1. `asReq`二分上界是 `.85 fc b d/fy`，即使需求超過容量仍回傳有限上界。數值驗證：M=1,000,000 tf·m、b=400 cm、d=70 cm、fc=210、fy=4200，回傳1190 cm²但φMn僅1137.045 tf·m。明細顯示「上界仍未達需求」，不將它宣稱為可行配筋。全體原結果維持不變。
2. 抗彎式假定鋼筋應力fy，未做應變相容鋼筋應力解；原有ductile判定仍保留。此為原實作模型，適用性尚需工程驗證。
3. 高沖切localAs判斷門檻用vdirect，但式子分子用vmax，與一般基腳工具目前用vdirect不同。完整揭露原式；未因跨工具差異自行更正。
4. 柱帶提供量是As×寬度比例，未逐支計數；band=min(基礎寬,柱寬+3h)，未以偏位截切；依原式逐项揭露。
5. 此引擎沒有伸展/錨定計算，也不以偏心或部分接觸本身單獨加入REVIEW；保留既有狀態並明確揭露範圍，不能把本組當作另一個一般基腳引擎。

發布仍待父對話確認全部工具範圍，需由根代理刷新遠端後整合。
