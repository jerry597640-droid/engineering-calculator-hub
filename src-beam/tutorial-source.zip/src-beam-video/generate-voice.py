"""Generate Taiwan female voice and provider word-boundary timestamps."""
import asyncio,json,subprocess,certifi
from pathlib import Path
certifi.where=lambda:'/etc/ssl/certs/ca-certificates.crt'
import edge_tts
root=Path(__file__).parent
voice='zh-TW-HsiaoChenNeural'
async def main():
    voices=await edge_tts.list_voices()
    selected=next(v for v in voices if v['ShortName']==voice)
    assert selected['Locale']=='zh-TW' and selected['Gender']=='Female'
    (root/'voice-metadata.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2))
    scenes=json.loads((root/'script.json').read_text())
    for i,scene in enumerate(scenes):
        path=root/'audio'/f'{i:02d}.mp3'
        bounds=[]
        with path.open('wb') as stream:
            async for chunk in edge_tts.Communicate(scene['text'],voice,rate='-5%',boundary='WordBoundary').stream():
                if chunk['type']=='audio':stream.write(chunk['data'])
                elif chunk['type']=='WordBoundary':bounds.append({'text':chunk['text'],'start':chunk['offset']/1e7,'end':(chunk['offset']+chunk['duration'])/1e7})
        duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]))
        scene.update(duration=duration+0.55,audioDuration=duration,words=bounds)
        print(i+1,scene['title'],round(duration,2),len(bounds),'boundaries',flush=True)
    start=0;transcript=[]
    for scene in scenes:
        scene['start']=start
        transcript.extend({**w,'start':w['start']+start,'end':w['end']+start} for w in scene['words'])
        start+=scene['duration']
    (root/'timed-scenes.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
    (root/'transcript.json').write_text(json.dumps({'source':'Microsoft Edge TTS WordBoundary','voice':voice,'words':transcript},ensure_ascii=False,indent=2))
    chapters=[{k:s[k] for k in ['title','text','start','duration']} for s in scenes]
    (root.parent/'src-beam/media/chapters.json').write_text(json.dumps(chapters,ensure_ascii=False,indent=2))
    print('TOTAL',round(start,2),flush=True)
asyncio.run(main())
