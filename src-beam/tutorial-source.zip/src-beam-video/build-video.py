from pathlib import Path
import json,html,subprocess
from PIL import Image
root=Path(__file__).parent
scenes=json.loads((root/'timed-scenes.json').read_text())
total=sum(c['duration'] for c in scenes)
esc=html.escape
def stamp(t):
    ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
captions=[]
for scene in scenes:
    words=scene['words']; group=[]
    for j,w in enumerate(words):
        if group and len(''.join(x['text'] for x in group))+len(w['text'])>23:
            captions.append({'text':''.join(x['text'] for x in group),'start':scene['start']+.15+group[0]['start'],'end':scene['start']+.15+w['start']-.02});group=[]
        group.append(w)
        if j==len(words)-1:captions.append({'text':''.join(x['text'] for x in group),'start':scene['start']+.15+group[0]['start'],'end':min(scene['start']+scene['duration']-.05,scene['start']+.15+group[-1]['end']+.1)})
vtt='WEBVTT\n\n'+'\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(captions))+'\n'
(root.parent/'src-beam/media/tutorial.vtt').write_text(vtt)
(root/'captions.json').write_text(json.dumps(captions,ensure_ascii=False))
parts=[];anim=[]
for i,s in enumerate(scenes):
    w,h=Image.open(root/f'assets/step-{i}.png').size
    width=640 if w<600 else 834
    newh=h*width/w
    pan=max(0,newh-404)
    start=s['start']; dur=s['duration']
    parts.append(f'''<section id="scene-{i}" class="scene" style="opacity:{1 if i==0 else 0}"><div class="scene-content"><div class="scene-head"><span class="brand">H</span><div class="titles"><small>SRC 梁斷面分析設計工作台 · 操作教學</small><h1>{esc(s['title'][3:])}</h1></div><span class="step">{i+1:02d} / 10</span></div><div class="main-grid"><div class="cue-panel"><p class="cue-label">這一步怎麼做</p>{''.join(f'<div class="cue cue-{j}"><span>{j+1}</span><p>{esc(n)}</p></div>' for j,n in enumerate(s['notes']))}<div class="voice-label">台灣女性旁白<br>zh-TW · HsiaoChen</div></div><div class="screen-wrap"><div class="screen-bar"><i></i><i></i><i></i><span>實際工作台畫面</span></div><div class="screen"><img class="capture-img" data-layout-allow-overflow src="assets/step-{i}.png" style="width:{width}px" alt="{esc(s['title'])}"></div></div></div><div class="foot"><span>{esc(s['title'])}</span><span>cm · kgf/cm² · tf · tf-m</span></div></div></section>''')
    if i:
        anim.append(f'tl.to("#scene-{i-1}",{{opacity:0,duration:.45,ease:"power2.inOut"}},{start});tl.to("#scene-{i}",{{opacity:1,duration:.45,ease:"power2.inOut"}},{start});')
    anim.append(f'tl.from("#scene-{i} .scene-head",{{y:16,opacity:0,duration:.6,ease:"power3.out",immediateRender:false}},{start+.2});')
    anim.append(f'tl.from("#scene-{i} .screen-wrap",{{scale:.985,opacity:0,duration:.7,ease:"sine.out",immediateRender:false}},{start+.3});')
    for j in range(3):anim.append(f'tl.from("#scene-{i} .cue-{j}",{{x:-18,opacity:0,duration:.5,ease:"power2.out",immediateRender:false}},{start+.5+j*.18});')
    anim.append(f'tl.to("#scene-{i} .capture-img",{{y:-{pan:.2f},scale:1.018,duration:{dur-1.4:.3f},ease:"sine.inOut"}},{start+1});')
    anim.append(f'tl.from("#scene-{i} .voice-label",{{opacity:0,duration:.5,ease:"sine.out",immediateRender:false}},{start+.8});tl.from("#scene-{i} .foot",{{opacity:0,duration:.4,ease:"power1.out",immediateRender:false}},{start+.4});')
audios=''.join(f'<audio id="vo-{i}" src="audio/{i:02d}.mp3" data-start="{s["start"]+.15:.5f}" data-duration="{s["audioDuration"]:.5f}" data-track-index="3" data-volume="1"></audio>' for i,s in enumerate(scenes))
caps=''.join(f'<div class="caption clip" id="cap-{i}" data-start="{c["start"]:.5f}" data-duration="{c["end"]-c["start"]:.5f}" data-track-index="4">{esc(c["text"])}</div>' for i,c in enumerate(captions))
out=f'''<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><script src="assets/gsap.min.js"></script><style>
@font-face{{font-family:SourceHanTC;src:url(assets/SourceHanTC.otf)}}*{{box-sizing:border-box}}body{{margin:0;width:1280px;height:720px;overflow:hidden;background:#eef3f6;color:#18374d;font-family:SourceHanTC}}.scene{{position:absolute;inset:0;width:1280px;height:720px;background:#eef3f6;overflow:hidden}}.scene-content{{width:100%;height:100%;padding:26px 30px 24px;display:flex;flex-direction:column;gap:20px}}.scene-head{{display:flex;align-items:center;gap:18px;height:90px;flex-shrink:0}}.brand{{display:flex;align-items:center;justify-content:center;font-family:SourceHanTC;font-size:43px;font-weight:900;border:3px solid #007f8e;color:#007f8e;width:64px;height:66px;border-radius:9px}}.titles{{flex:1}}.titles small{{color:#506778;font-size:21px}}h1{{font-size:43px;margin:2px 0 0;line-height:1.3}}.step{{font-family:SourceHanTC;font-size:24px;color:#007f8e}}.main-grid{{display:grid;grid-template-columns:344px 1fr;gap:24px;height:450px;flex-shrink:0}}.cue-panel{{background:#10283d;color:#fff;border-radius:12px;padding:22px;display:flex;flex-direction:column;gap:16px}}.cue-label{{color:#a6e5e9;font-size:21px;margin:0}}.cue{{display:flex;gap:11px;align-items:flex-start}}.cue>span{{color:#a6e5e9;font-family:SourceHanTC;font-size:24px}}.cue p{{font-size:23px;margin:0;line-height:1.5;flex:1}}.voice-label{{font-size:18px;color:#cadbe8;margin-top:auto;line-height:1.5}}.screen-wrap{{background:#fff;border:1px solid #d5e0e7;border-radius:12px;overflow:hidden;box-shadow:0 7px 24px #10283d15}}.screen-bar{{height:42px;display:flex;align-items:center;gap:8px;background:#fff;border-bottom:1px solid #d5e0e7;padding:0 16px;color:#506778;font-size:17px}}.screen-bar i{{width:9px;height:9px;border-radius:50%;background:#d5e0e7}}.screen-bar span{{margin-left:12px}}.screen{{height:406px;overflow:hidden;display:flex;justify-content:center;align-items:flex-start;background:#fff}}.capture-img{{display:block;max-width:none;flex:none;transform-origin:center top}}.foot{{font-size:17px;display:flex;justify-content:space-between;color:#506778;flex-shrink:0}}.caption{{position:absolute;left:30px;bottom:16px;width:1220px;height:64px;background:#10283d;color:white;display:flex;align-items:center;justify-content:center;font-size:25px;border-radius:7px;padding:0 24px;line-height:1.4;z-index:50}}.progress{{position:absolute;left:0;top:0;height:5px;width:1280px;background:#007f8e;transform-origin:left;z-index:60}}
</style></head><body><div id="root" data-composition-id="src-tutorial" data-start="0" data-duration="{total:.5f}" data-width="1280" data-height="720">{''.join(parts)}{audios}{caps}<div class="progress"></div></div><script>window.__timelines=window.__timelines||{{}};const tl=gsap.timeline({{paused:true}});{''.join(anim)}tl.fromTo('.progress',{{scaleX:0}},{{scaleX:1,duration:{total:.5f},ease:'none'}},0);window.__timelines['src-tutorial']=tl;</script></body></html>'''
(root/'index.html').write_text(out)
with (root/'STORYBOARD.md').open('a') as f:
    f.write('\n## Final measured chapter timing\n\n'+ '\n'.join(f'{s["title"]}: {s["start"]:.3f}–{s["start"]+s["duration"]:.3f} s' for s in scenes)+'\n')
print('Composition seconds',total,'caption groups',len(captions))
