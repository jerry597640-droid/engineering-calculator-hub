# SRC 梁工作台操作教學
Format: 1280×720, 24 fps. Audio: zh-TW-HsiaoChenNeural, Taiwan female, −5% speed. No background music; narration remains clear. Timing comes from provider word boundaries and measured MP3 lengths.
Style basis: DESIGN.md. Actual application panels, chapter numbers, three short operation cues, changing chapter progress. Calm editorial transitions of 0.45 seconds; elements enter with y/opacity, x/opacity, and scale. Screenshot slow zoom and vertical pan keep the current fields legible. Every scene has navigation identity, title, screenshot, three cues, and bottom spoken caption.

## Asset audit
| Asset | Scenes | Use |
|---|---|---|
| capture/screenshots/scroll-000.png | reference | Grounding only; replaced on screen by current step-0 |
| assets/step-0.png | 1 | Current RC neutral-axis section |
| assets/step-1.png | 2 | Concrete input form |
| assets/step-2.png | 3 | H steel form |
| assets/step-3.png | 4 | Actual layered rebar |
| assets/step-4.png | 5 | Stirrup / friction inputs |
| assets/step-5.png | 6 | Loads and conditions |
| assets/step-6.png | 7 | Actual strength results |
| assets/step-7.png | 8 | Numeric calculation report |
| assets/step-8.png | 9 | Searchable parameter dictionary |
| assets/step-9.png | 10 | Current code-version table |
| assets/section.svg | reference | Captured geometry reference; step-0 already contains current section |
| assets/SourceHanTC.otf | all | Captured-system Traditional Chinese glyphs |

## Chapters
1. Load example and explain navigation. Section diagram is the focal point; title and ordered action cues slide in. The screenshot rises softly and receives a slow push-in. First scene shows actual tool, not a text title card.
2. Read concrete inputs and units. Form is framed enlarged; camera slowly pans from dimensions to strengths and cover. Three cues appear sequentially beside it.
3. Convert steel millimetres to centimetres. Enlarge the H form and drift to centres and material grade. Exact conversion remains in the cue panel.
4. Configure top and bottom layers. Pan through actual rebar layer cards. Explain single-bar area and individual-coordinate mode.
5. Stirrup and friction: form drifts from stirrup to Avf and interface. Emphasize verified anchorage and zero undocumented stud contribution.
6. Factored loads: show real 100 tf-m / 35 tf entries and true condition flags. Explain load pairing without inventing combinations.
7. Read the actual six capacity ratios. Own cue panel shows 145.17 and 0.689. Screenshot slowly scales without covering results.
8. Detailed calculation formulas. Show actual plastic-section substitutions; point to report/iteration navigation. Preserve existing Word export.
9. Parameter search and JSON project workflow. Show actual Avf dictionary result, inquiry key, then full definition. Cue panel gives the save/import sequence.
10. Offline and official code versions. Show the official code-version table. Remind that full seismic, connections and construction checks remain separate. Final state holds through the last spoken word.

## Timing
Generated automatically from timed-scenes.json; narration audio starts 0.15 seconds after each scene begins. Each audio file receives 0.55 seconds of visual breathing room. All chapter offsets are also embedded in the webpage.

## Source tree
index.html, DESIGN.md, SCRIPT.md, STORYBOARD.md, narration.txt, transcript.json, timed-scenes.json, script.json, voice-metadata.json, audio/*.mp3, assets/*, renders/src-beam-tutorial.mp4.

## Final measured chapter timing

01 載入範例與工作流程: 0.000–16.342 s
02 混凝土與材料: 16.342–34.412 s
03 H 型鋼尺寸與位置: 34.412–53.994 s
04 分層與逐支主筋: 53.994–74.776 s
05 箍筋與剪力摩擦: 74.776–95.294 s
06 因數化需求與工程條件: 95.294–112.908 s
07 判讀強度與構造檢核: 112.908–131.530 s
08 計算明細與 Word 匯出: 131.530–149.336 s
09 參數字典與專案儲存: 149.336–168.822 s
10 離線使用與規範範圍: 168.822–191.284 s
