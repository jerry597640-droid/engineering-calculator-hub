"""Deterministic captioned tutorial; values come from the calculator test data."""
from pathlib import Path
import base64,html,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parent
APP=ROOT.parent
P=ROOT/'composition'
(P/'assets').mkdir(exist_ok=True)
D=json.loads((ROOT/'video-data.json').read_text())
e=html.escape
def fields(rows):
 return '<div class="fields">'+''.join('<div class="field"><small>'+e(k)+'</small><strong>'+e(v)+'</strong></div>' for k,v in rows)+'</div>'
def controls(active):
 return '<div class="options">'+''.join('<div class="option '+('target selected' if n==active else '')+'">'+('● ' if n==active else '○ ')+n+'</div>' for n in ['上翼板','下翼板','上下翼板','腹板','翼板＋腹板（合併篩檢）'])+'</div>'
def section(top=False,bottom=False,web=False):
 s='<svg class="section" viewBox="0 0 460 220" role="img" aria-label="開孔位置示意"><path d="M90 25h120v12h-54v136h54v12H90v-12h54V37H90z" fill="#698da6"/>'
 for on,y in [(top,25),(bottom,173)]:
  if on:
   for x in [113,171]:s+=f'<rect x="{x}" y="{y}" width="12" height="12" fill="#fff" stroke="#c65a35" stroke-width="3"/>'
 if web:s+='<rect x="144" y="83" width="12" height="48" fill="#fff" stroke="#c65a35" stroke-width="3"/>'
 return s+'<text x="244" y="58">上翼板</text><text x="244" y="115">腹板</text><text x="244" y="174">下翼板</text><text x="90" y="216" class="svg-note">橘色：開孔臨界截面示意</text></svg>'
def panel(left,right):return '<div class="grid"><div class="card">'+left+'</div><div class="card">'+right+'</div></div>'
def stat(label,value):return '<div class="metric"><small>'+label+'</small><strong>'+value+'</strong></div>'
def flange_scene(pos,title,subtitle,captions):
 q=next(x for x in D['positions'] if x['position']==pos)
 label={'top':'上翼板','bottom':'下翼板','both':'上下翼板'}[pos]
 rows=[('標稱孔徑 d','18 mm')]+([('上翼板同排孔數',str(q['nt']))] if q['nt'] else [])+([('下翼板同排孔數',str(q['nb']))] if q['nb'] else [])+[('使用載重彎矩 M','20 tf·m')]
 if pos!='both':rows.append(('孔徑扣除模式','標稱＋1.5 mm'))
 left='<h2>開孔位置：'+label+'</h2>'+fields(rows)+'<p class="note target">只計入選定位置的孔數</p>'
 right=section(q['nt']>0,q['nb']>0)+stat('淨斷面彎矩參考',f'{q["Mnet"]:.3f} tf·m')+'<div class="pairs"><span>保留率 '+f'{q["retention"]:.2f}%</span><span>形心 '+f'{q["centroid"]:.3f} cm</span></div>'
 return dict(title=title,subtitle=subtitle,content=panel(left,right),duration=14,captions=captions)
scenes=[
 dict(title='先選擇開孔位置',subtitle='位置、輸入欄位、圖形與計算結果會同步切換',duration=14,
 content=panel('<h2>左側「開孔位置」</h2>'+controls('上翼板'),section(True)+'<p class="note">依施工圖選擇位置，再填同一臨界斷面的孔數。</p>'),
 captions=['第一步，選上翼板、下翼板、上下翼板、腹板，或翼板加腹板。','翼板孔數是同一橫斷面穿過的孔數，不能把不同排全部累加。','本片為字幕動畫操作示範，欄位名稱與數值取自本程式。']),
 dict(title='尺寸與原梁結實性',subtitle='尺寸取結構圖，鋼材強度取符合板厚的材證',duration=14,
 content=panel('<h2>共通尺寸與材料</h2>'+fields([('H / B','50 / 20 cm'),('tw / tf','1 / 1.6 cm'),('Fy','325 MPa'),('Lb','100 cm')])+'<p class="target note">確認翼板與腹板全長連續連接</p>', '<h2>按「梁結實檢核」</h2>'+stat('翼板 B/(2tf)', '6.250 ≤ 9.338')+stat('腹板 (H−2tf)/tw','46.800 ≤ 93.383')+'<p class="note">原梁結實不代表孔邊及整體穩定已通過。</p>'),
 captions=['填入梁尺寸與 Fy，再依詳圖確認翼板及腹板連續連接。','結實檢核分列翼板與腹板寬厚比，兩項都須符合限值。','若側撐間距 Lb 超過 Lc，仍須另案驗證容許應力 Fb。']),
 flange_scene('top','上翼板開孔','本例正彎矩：上翼板受壓；孔邊局部穩定須另核',
 ['選上翼板，只顯示並計入上翼板同排孔數。','範例填18毫米標稱孔徑、2孔；程式依ASD扣孔模式加1.5毫米。','本例上翼板受壓，即使彎矩參考使用比小於1，仍維持條件待覆核。']),
 flange_scene('bottom','下翼板開孔','相同尺寸與孔數，形心會相對梁中線鏡射',
 ['切換下翼板；上翼板孔數不納入這次計算。','上、下位置互換時形心鏡射，本例彎矩參考值相同。','把彎矩改成負值，受壓側會換到下翼板，適用條件也要重新確認。']),
 flange_scene('both','上下翼板同時開孔','上下孔數分別輸入；程式合併重算形心與慣性矩',
 ['選上下翼板，填上2孔、下2孔；不是把總數4孔填在同一側。','孔數相等時形心維持梁中央；本例彎矩參考降為33.881噸力米。','淨斷面篩檢、規範有效斷面與完整構材設計，仍須分別判讀。']),
 dict(title='腹板單孔彎剪檢核',subtitle='按「載入公開案例」：DG2 W24×55，矩形偏心孔',duration=18,
 content=panel('<h2>選腹板 → 載入公開案例</h2>'+fields([('方法','DG2 LRFD'),('孔高 / 孔長','25.4 / 50.8 cm'),('偏心 e','−5.08 cm'),('Mu / Vu','39.979 tf·m / 5.443 tf')])+'<p class="target note">LRFD 必須輸入已因數化需求</p>', '<h2>公開案例：離支承12 ft載重點</h2><svg class="web" viewBox="0 0 460 180"><path d="M35 20H425V155H35z" fill="#d5e3ed" stroke="#698da6" stroke-width="5"/><rect x="150" y="65" width="130" height="65" rx="5" fill="#fff" stroke="#c65a35" stroke-width="3"/></svg>'+stat('彎剪交互作用 R','0.926 ≤ 1.000')+'<p class="note">單一無補強孔；須確認側撐及適用條件。</p>'),
 captions=['腹板可選矩形孔或圓孔，孔洞尺寸以公分輸入。','ASD填工作載重，程式轉換一次；LRFD填已因數化的彎矩與剪力。','公開案例原文R約0.93，本程式0.926；剪力容量約0.40%的差異已揭露。']),
 dict(title='翼板＋腹板合併篩檢',subtitle='同區開孔不可以把兩個單獨通過結果直接合併',duration=18,
 content=panel('<h2>載入翼板＋腹板範例</h2>'+fields([('翼板位置','上下翼板'),('上 / 下同排孔數','2 / 2 孔'),('腹板孔高 / 長','20 / 30 cm'),('M / V','20 tf·m / 10 tf')])+'<p class="target note">合併模式使用 ASD 工作載重</p>',section(True,True,True)+stat('合併淨斷面彎矩參考',f'{D["combined"]["M"]:.3f} tf·m')+'<p class="pending">整體承載力：待另案覆核</p>'),
 captions=['先選翼板加腹板，再選上、下或上下翼板；兩組孔洞資料都要填。','合併淨斷面以同一臨界截面扣孔；本例彎矩參考為33.298噸力米。','純腹板DG2數值僅供對照，不能當作聯合孔洞剪力容量，也不顯示整體通過。']),
 dict(title='檢視依據，匯出與離線',subtitle='把輸入來源、適用條件與計算過程一起保留',duration=18,
 content=panel('<h2>右側功能列</h2><div class="options"><div class="option">梁結實檢核</div><div class="option">操作說明／規範來源</div><div class="option target">儲存輸入 JSON／匯出 Word</div><div class="option">釘選圖形／取消釘選</div></div>', '<h2>下載完整離線 ZIP</h2><div class="flow"><span>解壓縮</span><b>→</b><span>開啟 index.html</span></div><p>保留 media 資料夾，影片即可離線播放。</p><p>手機可用下拉選位置；影片可暫停或跳至指定章節。</p><p class="note">圖示、範例與驗算說明都在程式內。</p>'),
 captions=['查看位置選擇說明與規範來源，再儲存JSON或匯出Word計算書。','右側圖形可釘選或取消；影片章節按鈕可定位後再播放。','下載完整離線ZIP，解壓並保留media資料夾，即可離線計算與觀看影片。'])]
css='''
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;font-family:TutorialTC;color:#1d3347;background:#eef3f6}#tutorial-film{width:100%;height:100%;position:relative;overflow:hidden}.scene{position:absolute;inset:0;width:100%;height:100%}.surface{width:100%;height:100%;padding:28px 42px 110px;display:flex;flex-direction:column;gap:12px;background:#eef3f6}.topline{height:40px;flex-shrink:0;display:flex;justify-content:space-between;align-items:center;padding:6px 16px;background:#102b43;color:#fff;font-size:22px;border-radius:6px}h1{font-size:60px;line-height:1.15;margin:5px 0 0;font-weight:700}h2{font-size:27px;margin:0 0 12px;font-weight:700}.subtitle{font-size:26px;line-height:1.4;margin:0 0 3px;color:#4b6474}.grid{display:grid;grid-template-columns:1fr 1.15fr;gap:20px;flex:1;min-height:0}.card{background:#fff;border:2px solid #d6e1e8;border-radius:12px;padding:20px;min-width:0}.fields{display:grid;grid-template-columns:1fr 1fr;gap:12px}.field{padding:10px 12px;border:2px solid #bacbd8;border-radius:7px;background:#fff;min-width:0}.field small{display:block;font-size:22px}.field strong{display:block;font-size:28px;margin-top:5px;font-variant-numeric:tabular-nums}.option{font-size:27px;border:2px solid #d6e1e8;border-radius:7px;padding:8px 12px;margin-bottom:8px;background:#fff}.selected{border-color:#096c9c;background:#eaf5fa;color:#096c9c}.target{transform-origin:center}.note{font-size:24px;line-height:1.45;margin:12px 0 0;color:#4b6474}p{font-size:27px;line-height:1.5;margin:14px 0}.section{width:100%;height:180px;display:block}.section text{font-family:TutorialTC;fill:#1d3347;font-size:25px}.section .svg-note{font-size:20px}.metric{padding:10px 15px;background:#eef3f6;border-radius:7px;margin:8px 0}.metric small{font-size:23px;display:block}.metric strong{font-size:42px;color:#096c9c;font-variant-numeric:tabular-nums;display:block;line-height:1.25}.pairs{display:flex;justify-content:space-between;gap:12px;font-size:24px;font-variant-numeric:tabular-nums}.web{width:100%;height:150px}.pending{padding:9px 14px;border-left:5px solid #c65a35;background:#fff1e8;color:#6b351e;font-size:27px;margin:10px 0}.caption{position:absolute;left:42px;right:42px;bottom:20px;min-height:72px;display:flex;align-items:center;justify-content:center;padding:10px 20px;background:#102b43;color:#fff;border-radius:7px;font-size:28px;line-height:1.45;text-align:center;opacity:0}.flow{display:flex;align-items:center;gap:16px;font-size:28px;background:#eef3f6;padding:16px;border-radius:8px}
'''
alltext=''.join(x['title']+x['subtitle']+x['content']+''.join(x['captions']) for x in scenes)+'鋼梁開孔操作教學字幕動畫示範0123456789/ABCDEFGHIJKLMNOPQRSTUVWXYZ'
needed=set(map(ord,alltext));faces=[]
fontroot=ROOT/'node_modules/@fontsource/lxgw-wenkai-tc'
for block in re.findall(r'@font-face\s*\{.*?\}',(fontroot/'400.css').read_text(),re.S):
 codes=set()
 for lo,hi in re.findall(r'U\+([0-9A-Fa-f]+)(?:-([0-9A-Fa-f]+))?',block):codes.update(range(int(lo,16),int(hi or lo,16)+1))
 if not codes.intersection(needed):continue
 src=re.search(r'url\(([^)]+\.woff2)\)',block).group(1)
 block=re.sub(r'  src:.*?;','  src: url(data:font/woff2;base64,'+base64.b64encode((fontroot/src).read_bytes()).decode()+") format('woff2');",block)
 faces.append(block.replace("'LXGW WenKai TC'",'TutorialTC').replace('font-display: swap','font-display: block'))
shutil.copyfile(ROOT/'node_modules/gsap/dist/gsap.min.js',P/'assets/gsap.min.js')
shutil.copyfile(fontroot/'LICENSE',P/'FONT-LICENSE.txt')
clips=[];animations=[];chapters=[];cues=[];start=0
for i,s in enumerate(scenes):
 sid=f's{i+1}';duration=s['duration'];chapters.append(dict(title=s['title'],start=start,duration=duration))
 caps=[]
 for j,text in enumerate(s['captions']):
  a=start+.5+j*(duration-.8)/3;b=start+.5+(j+1)*(duration-.8)/3-.1;cid=f'{sid}-cap{j}'
  caps.append(f'<div id="{cid}" class="caption">{e(text)}</div>')
  animations.append(f"tl.fromTo('#{cid}',{{opacity:0,y:5}},{{opacity:1,y:0,duration:.25,ease:'sine.out'}},{a});tl.set('#{cid}',{{opacity:0}},{b});")
  cues.append(dict(start=a,end=b,text=text))
 clipduration=duration+(.4 if i<len(scenes)-1 else 0)
 clips.append(f'<div id="{sid}" class="clip scene" data-start="{start}" data-duration="{clipduration}" data-track-index="{i+1}" style="z-index:{i}"><div id="{sid}-surface" class="surface"><div id="{sid}-top" class="topline"><span data-layout-allow-overlap>鋼梁開孔操作教學</span><span data-layout-allow-overlap>{i+1:02d} / 08 · 字幕動畫示範</span></div><h1 id="{sid}-title">{e(s["title"])}</h1><p id="{sid}-sub" class="subtitle">{e(s["subtitle"])}</p><div id="{sid}-panel">{s["content"]}</div>{"".join(caps)}</div></div>')
 animations.append(f"tl.from('#{sid}-surface',{{opacity:0,duration:.4,ease:'power2.out'}},{start});tl.from('#{sid}-top',{{y:7,opacity:0,duration:.35,ease:'sine.out'}},{start+.1});tl.from('#{sid}-title',{{y:15,opacity:0,duration:.5,ease:'power3.out'}},{start+.2});tl.from('#{sid}-sub',{{y:9,opacity:0,duration:.4,ease:'power2.out'}},{start+.32});tl.from('#{sid}-panel',{{y:11,opacity:0,duration:.5,ease:'sine.out'}},{start+.45});tl.fromTo('#{sid} .target',{{scale:1}},{{scale:1.018,duration:.5,repeat:1,yoyo:true,ease:'power2.inOut'}},{start+3});")
 start+=duration
css+='#s1-panel,#s2-panel,#s3-panel,#s4-panel,#s5-panel,#s6-panel,#s7-panel,#s8-panel{flex:1;min-height:0;display:flex;flex-direction:column}#s8-panel .card p{font-size:26px}'
host=f'<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><script src="assets/gsap.min.js"></script><style>{"".join(faces)}{css}</style></head><body><div id="tutorial-film" data-composition-id="tutorial-film" data-width="1280" data-height="720" data-fps="24" data-duration="{start}">{"".join(clips)}</div><script>window.__timelines=window.__timelines||{{}};const tl=gsap.timeline({{paused:true}});{"".join(animations)}window.__timelines["tutorial-film"]=tl;</script></body></html>'
(P/'index.html').write_text(host)
(ROOT/'chapters.json').write_text(json.dumps(dict(duration=start,chapters=chapters,captions=cues),ensure_ascii=False,indent=2))
(P/'STORYBOARD.md').write_text('# Captioned steel-beam openings tutorial\n'+''.join(f'\n## {i+1}. {s["title"]}\n{s["subtitle"]}\n'+'\n'.join(s['captions'])+'\n' for i,s in enumerate(scenes)))
def ts(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}.{ms%1000:03d}'
(APP/'media').mkdir(exist_ok=True)
(APP/'media/tutorial.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{i+1}\n{ts(c["start"])} --> {ts(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n')
print(json.dumps(dict(duration=start,scenes=len(scenes),font_subsets=len(faces),captions=len(cues))))
