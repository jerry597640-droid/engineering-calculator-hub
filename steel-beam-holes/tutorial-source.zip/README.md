# Steel beam opening tutorial source

124-second, 1280×720, 24fps captioned tutorial, no narration. Source numbers are produced by engine.js and web-engine.js into video-data.json. Eight scenes follow the deployed calculator field labels and explicitly keep the combined flange/web nominal strength pending.

Build: npm install; python build-video.py. In composition/: npm run check; npm run render. The composition uses HyperFrames 0.8.146. A Chromium binary must be installed for local rendering; HYPERFRAMES_BROWSER_PATH can point to it. Font and GSAP package versions are retained in package-lock.json. No cloud media generation is required.

Validation: runtime and contrast pass; all eight hero frames reviewed. The eight nested_structure_needs_subcomposition lint warnings are intentional: this is a small monolithic composition with one root timeline. Scene overlap exists only for the 0.4-second opacity crossfade; outgoing and incoming header/label overlap is intentional during that transition. There are no content overflow warnings at the eight hero frames. Refer to check.json for detailed audits.

The rendered video, poster and VTT are shipped in ../media. Re-render from this source rather than editing capacity labels by hand.
