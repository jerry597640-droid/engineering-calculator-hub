const fs=require('node:fs'),path=require('node:path');
const H=require('../engine.js'),W=require('../web-engine.js');
const p={H:50,B:20,tw:1,tf:1.6,Fy:325,d:18,nt:2,nb:2,Lb:100,M:20,Fb:0,add:1.5};
const w={shape:'rect',design:'asd',ho:20,ao:30,e:0,V:10,M:20,edge:100,radius:2.1,Z:0,braced:true,conditions:true,teeVerified:false};
const c=H.calcCombined(H.withPosition(p,'combined','both'),w);
fs.writeFileSync(path.join(__dirname,'video-data.json'),JSON.stringify({positions:JSON.parse(fs.readFileSync(path.join(__dirname,'../position-verification.json'))).examples,compact:H.compactness(p),combined:{A:c.n.A,y:c.n.y,I:c.n.I,ret:c.r*100,M:c.mn,ratio:c.ratio},web:W.calcWeb(p,w)},null,2));
