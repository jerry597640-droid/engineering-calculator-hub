# Visual identity — retained engineering workbench
## Style Prompt
A light technical worksheet that teaches the existing steel beam opening workbench. Retain the deployed app palette and control labels. Large Traditional Chinese labels, exact numerical outputs from the calculation engine, orange hole marks, restrained highlight motion. This is a captioned animated demonstration, not a live screen recording.
## Colors
- #102b43: header and caption canvas, from app --nav
- #eef3f6: page background, from app body
- #096c9c: active controls and quantitative emphasis, from app --blue
- #c65a35: opening outline, from app web diagram
- #1d3347: body text, from app --ink
## Typography
LXGW WenKai TC is the installed Traditional Chinese teaching font, chosen for legibility of Chinese engineering terms. Use 60px headings, 28px body, 24px labels. Use ui-monospace for Latin numerals and formula values. No pair of similar sans-serif fonts.
## Motion
Use 0.4-second opacity crossfades between scenes. Elements enter with small translations, then hold long enough to read. Controls pulse once to show the next operation. No decorative motion while interpreting a result.
## What NOT to Do
- Do not claim the combined flange/web reference is a certified joint strength.
- Do not show a joint PASS badge.
- Do not replace working controls with invented labels.
- Do not cram a full desktop page into one frame.
