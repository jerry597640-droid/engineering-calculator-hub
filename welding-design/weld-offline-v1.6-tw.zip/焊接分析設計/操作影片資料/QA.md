# Tutorial verification

- 9 hero frames reviewed; real UI screenshots and diagram video remain legible at 1280×720.
- Full HyperFrames check: pass; no runtime errors, motion errors, or contrast failures (50/50 checks).
- Lint: 0 errors, 9 advisory warnings recommending subcomposition files. Inline chapters intentionally retained in a single deterministic source for maintainability.
- Inspect: 0 issues at all 9 fully visible chapter frames. Crossfade overlap diagnostics at boundaries are intentional.
- Animation map: full-frame scene/screenshot collision flags are intentional parent/child layering. Nine paced-slow flags are the restrained 1% Ken Burns holds, not slow entrances. No dead zones.
- Caption chapter boundaries measured from PCM audio. Taiwan voice update uses speech-service SentenceBoundary timestamps, scaled with the small chapter tempo adjustment.
- Original v1.6 narration used zf_xiaobei. This update replaces all nine chapters with zh-TW-HsiaoChenNeural, a Taiwan Mandarin female voice. No music.
- Studio background preview attempted twice, but environment health probes failed with `fatal library error, lookup self`; no ready Studio URL claimed. Headless check, snapshot, and renderer remain usable.

## Final rendered output

HyperFrames render completed all 3386 frames in 182.6 seconds. The 7.6 MB master was transcoded once to H.264 CRF30 / AAC64k mono with faststart, 1280×720 at 24fps. Final size 3,416,328 bytes; video duration 141.083333s, audio duration 141.077s. All nine chapters and two distinct drag states checked from the actual final MP4. No fallback renderer used.

## Taiwan voice update
All nine chapters use zh-TW-HsiaoChenNeural. Existing visual timeline retained; source audio receives a small per-chapter tempo adjustment to fit its existing slot. Sentence subtitles are rebuilt from provider timestamps. See taiwan/validation.json.
